--[[

This place is a message... and part of a system of messages... pay attention to it!

Sending this message was important to us. We considered ourselves to be a powerful culture.

This place is not a place of honor... no highly esteemed deed is commemorated here... nothing valued is here.

What is here was dangerous and repulsive to us. This message is a warning about danger.

The danger is in a particular location... it increases towards a center... the center of danger is here... of a particular size and shape, and below us.

The danger is still present, in your time, as it was in ours.

The danger is to the body, and it can kill.

The form of the danger is an emanation of energy.

The danger is unleashed only if you substantially disturb this place physically. This place is best shunned and left uninhabited.

]]--





-- ... in other words ugly code with very few comments ahead



if not P1 or not P2 then
	backToSongWheel('Two Player Mode Required')
	return
end
function modulo(a,b) return a - math.floor(a/b) * b end
-- judgment / combo proxies
for pn = 1, 2 do
	setupJudgeProxy(PJ[pn], P[pn]:GetChild('Judgment'), pn)
	setupJudgeProxy(PC[pn], P[pn]:GetChild('Combo'), pn)
end
-- player proxies
for plrnum = 1, #PP do
	plrproxies = PP[plrnum]
	P[plrnum]:SetAwake(true)
	for proxnum = 1,#plrproxies do
		PP[plrnum][proxnum]:SetTarget(P[plrnum])
		PP[plrnum][proxnum]:xy(0,0)
		if plrnum > 2 then
			PP[plrnum][proxnum]:hidden(1)
		end
	end
	P[plrnum]:SetInputPlayer((plrnum+1)%2)
	P[plrnum]:hidden(1)
	P[plrnum]:xy(sw/2,sh/2-10)
	if plrnum > 2 then
		P[plrnum]:GetChild('Judgment'):hidden(1)
		P[plrnum]:GetChild('Combo'):hidden(1)
	end
end
-- your code goes here here:

local slumpo = (GAMESTATE:GetCurrentSteps(0) or GAMESTATE:GetCurrentSteps(1)):GetDifficulty() == DIFFICULTY_EDIT

-- card {start, end, 'spellcard name', (diff as int), '#420699'}
card {0, 32, 'wiggle', 8, '#1FBB77'}
if not slumpo then
	card {32.001, 95.999, 'coin but easier', 15, '#417C5B'}
else
	card {32.001, 95.999, 'coin but harder but easier', 18, '#417C5B'}
end
if not slumpo then
	card {96, 128, 'wiggle 2', 9, '#1FBB77'}
else
	card {96, 128, 'lifebar break', 9, '#1FBB77'}
end
if not slumpo then
	card {128.001, 196, 'coin but easier but in the other direction', 16, '#417C5B'}
else
	card {128.001, 196, 'coin but harder but harder', 20, '#2f4d3c'}
end

--time for the god awful definemods i guess....
totrad = 0
definemod{'totalRadius', function(tr, plr)
	if tr ~= -42069 then
		totrad = tr
		for i=0,3 do
			xero['rad'..i] = modulo(50 + 50*i + tr, 400) + 100
			if plr > 2 then
				xero['rad'..i] = modulo(400 - 50*i + tr, 400) + 100
			end
			xero['tin'..i] = 0
			if xero['rad'..i] < 150 then
				xero['tin'..i] = 4 * (150 - xero['rad'..i])
			end
			if xero['rad'..i] > 450 then
				xero['tin'..i] = 4 * (xero['rad'..i] - 450)
			end
		end
		--print('rad0 should be ' .. xero['rad0'])
		return xero['rad0'], xero['rad1'], xero['rad2'], xero['rad3'], xero['tin0'], xero['tin1'], xero['tin2'], xero['tin3'], 100 - xero['tin0']/2, 100 - xero['tin1']/2, 100 - xero['tin2']/2, 100 - xero['tin3']/2
	else
		return 0,0,0,0,0,0,0,0,0,0,0,0
	end
end, 'radius0', 'radius1', 'radius2', 'radius3', 'tiny0', 'tiny1', 'tiny2', 'tiny3', 'arrowpath0', 'arrowpath1', 'arrowpath2', 'arrowpath3'}
definemod{'radius0', 'radius1', 'radius2', 'radius3', 'spin', 'dir', function(r0, r1, r2, r3, sp, dir, pn)
	
	local plr = P[pn]
	local angle = sp*math.pi/100 + (math.pi * (pn%2))
	--print(pn .. ' ' .. angle .. ' ' .. sp*math.pi/100 .. ' ' .. (math.pi * (pn%2)))
	local dir2 = 1
	if dir < 0 then
		dir2 = -1
	end
	--print('rad0: ' .. r0)
	if r0 > 0 then
		-- curve
		for xpos=0,20 do
			-- from -150 to 600: -150 + xpos*37.5
			local offset = -150 + xpos*37.5
			local adjangle = angle + dir2*(-math.pi/4 + math.pi*xpos/16)
			plr:SetXSpline(xpos, 0, r0 * math.cos(adjangle), offset, -1)
		end
		for ypos=0,20 do
			local offset = -150 + ypos*37.5
			local adjangle = angle + dir2*(-math.pi/4 + math.pi*ypos/16)
			plr:SetYSpline(ypos, 0, r0 * math.sin(adjangle), offset, -1)
		end
	end
	if r1 > 0 then
		-- curve
		for xpos=0,20 do
			-- from -150 to 600: -150 + xpos*37.5
			local offset = -150 + xpos*37.5
			local adjangle = angle + dir2*(-math.pi/4 + math.pi*xpos/16)
			plr:SetXSpline(xpos, 1, r1 * math.cos(adjangle), offset, -1)
		end
		for ypos=0,20 do
			local offset = -150 + ypos*37.5
			local adjangle = angle + dir2*(-math.pi/4 + math.pi*ypos/16)
			plr:SetYSpline(ypos, 1, r1 * math.sin(adjangle), offset, -1)
		end
	end
	if r2 > 0 then
		-- curve
		for xpos=0,20 do
			-- from -150 to 600: -150 + xpos*37.5
			local offset = -150 + xpos*37.5
			local adjangle = angle + dir2*(-math.pi/4 + math.pi*xpos/16)
			plr:SetXSpline(xpos, 2, r2 * math.cos(adjangle), offset, -1)
		end
		for ypos=0,20 do
			local offset = -150 + ypos*37.5
			local adjangle = angle + dir2*(-math.pi/4 + math.pi*ypos/16)
			plr:SetYSpline(ypos, 2, r2 * math.sin(adjangle), offset, -1)
		end
	end
	if r3 > 0 then
		-- curve
		for xpos=0,20 do
			-- from -150 to 600: -150 + xpos*37.5
			local offset = -150 + xpos*37.5
			local adjangle = angle + dir2*(-math.pi/4 + math.pi*xpos/16)
			plr:SetXSpline(xpos, 3, r3 * math.cos(adjangle), offset, -1)
		end
		for ypos=0,20 do
			local offset = -150 + ypos*37.5
			local adjangle = angle + dir2*(-math.pi/4 + math.pi*ypos/16)
			plr:SetYSpline(ypos, 3, r3 * math.sin(adjangle), offset, -1)
		end
	end
	
	if r0 > 0 or r1 > 0 or r2 > 0 or r3 > 0 then
		plr:SetStealthSpline(0, -1, 100, -75, -1)
		plr:SetStealthSpline(1, -1, 0, 0, -1)

		plr:SetSizeSpline(0, -1, 0, 400, -1)
		plr:SetSizeSpline(1, -1, 200, 600, -1)
	end
end}

bggap = 200
definemod{'bggap', function(b)
	if b < 0.01 then
		bggap = 0.01 -- no infinite loops
	else
		bggap = b
	end
end}

--the
definemod{'rotx','roty','rotz',function(xDegrees, yDegrees, zDegrees, plr)
    local axes = xDegrees ~= 0 and 1 or 0 + yDegrees ~= 0 and 1 or 0 and zDegrees ~= 0 and 1 or 0
    local angles
    local DEG_TO_RAD = math.pi / 180
    if axes > 1 then
        local function mindf_reverseRotation(angleX, angleY, angleZ)
            local sinX = math.sin(angleX);
            local cosX = math.cos(angleX);
            local sinY = math.sin(angleY);
            local cosY = math.cos(angleY);
            local sinZ = math.sin(angleZ);
            local cosZ = math.cos(angleZ);
            return { math.atan2(-cosX*sinY*sinZ-sinX*cosZ,cosX*cosY),
                    math.asin(-cosX*sinY*cosZ+sinX*sinZ),
                    math.atan2(-sinX*sinY*cosZ-cosX*sinZ,cosY*cosZ) }
        end
        angles = mindf_reverseRotation(xDegrees * DEG_TO_RAD, yDegrees * DEG_TO_RAD, zDegrees * DEG_TO_RAD)
    else
        angles = { -xDegrees * -DEG_TO_RAD, -yDegrees * DEG_TO_RAD, -zDegrees * DEG_TO_RAD }
    end
    local rotationx,rotationy,rotationz=
        xDegrees,
        yDegrees,
        zDegrees
    local confusionxoffset,confusionyoffset,confusionzoffset=
        (angles[1]*100),
        (angles[2]*100),
        (angles[3]*100)

    return rotationx,rotationy,rotationz,confusionxoffset,confusionyoffset,confusionzoffset
end,
'rotationx','rotationy','rotationz','confusionxoffset','confusionyoffset','confusionzoffset'
}

definemod {'blur', function(p)
	blur1sprite:diffusealpha(p/100)
	blur2sprite:diffusealpha(p/100)
	blur1sprite:GetShader():uniform1f('samplesMult', -0.95 + p/100)
	blur2sprite:GetShader():uniform1f('samplesMult', -0.95 + p/100)
	
end}

circleCount = 4
flashDist = 0
flashRot = 0
flashSize = 0
definemod {'circlecount', 'flashdist', 'flashrot', 'flashsize', function(p, d, r, s)
	circleCount = p
	flashDist = d
	flashRot = r
	flashSize = s
end}


setdefault{0, 'blur', 200, 'cmod', -42069, 'totalRadius', 5000, 'bggap', 4, 'circleCount', 0, 'flashDist', 200, 'flashsize'}
func{0, function()
	
	--general setup
	
	bgquad:hidden(0)
	bgquad:xywh(sw/2, sh/2, sw, sh)
	bgquad:diffuse(31/255, 187/255, 119/255,1)
	blur1sprite:SetTexture(blur1aft:GetTexture())
	blur2sprite:SetTexture(blur2aft:GetTexture())
	blur1sprite:GetShader():uniform1i('isVert', 0)
	blur2sprite:GetShader():uniform1i('isVert', 1)
	blur1sprite:blend('normal')
	blur2sprite:blend('normal')
end}
set{-2, 180, 'mini', 100, 'beat', 200, 'modtimer', 100, 'dizzyholds'}
ease{0, 8, outCubic, 0, 'mini'}

func{0, function()
	
	--bg setup
	
	circle:hidden(0)
	circle:zwrite(1)
	circle:xywh(sw/2, sh/2, sw/2, sw/2)
	circle:blend('noeffect')
	circletexture:hidden(0)
	circletexture:diffuse(1,1,1,1)
	circletexture:xywh(sw/2, sh/2, sw, sh)
	circletexture:ztest(1)
	circletexture:ztestmode('writeonfail')
	gridtexture:diffuse(0,0,0,1)
	gridtexture:hidden(0)
	gridtexture:customtexturerect(0, 0, 32, 32)
	gridtexture:xywh(sw/2, sh/2, sw*2, sw*2)
	gridtexture:ztest(1)
	gridtexture:ztestmode('writeonfail')
	gridtexture:texcoordvelocity(0.2,0.08)
	bgcircleframe:SetDrawFunction(function()
		-- bg texture for end
		circletexture:diffuse(31/255, 187/255, 119/255, 1)
		gridtexture:diffuse(65/255, 124/255, 91/255, 0.3)
		gridtexture:rotationz(10)
		circle:xywh(sw/2,sh/2,sw*2,sw*2)
		circle:Draw()
		circletexture:Draw()
		gridtexture:Draw()
		clearbuffer:Draw()
		
		-- concentric circles
		local raddiff = bggap
		local scale = raddiff/200
		local currad = (modulo(scale*totrad + 150, raddiff) + 20*raddiff)
		local a = -1
		
		if modulo((scale*totrad+150) / raddiff, 2) >= 1 then
			a = 1
		end
		local idkvariablenames = 200-bggap
		currad = currad - (25 + idkvariablenames*0.625) -- center playfields in color gaps (idk why these numbers work)
		--0 mini/200 bggap - 25
		--50 mini/150 bggap - 56.25
		--100 mini/100 bggap - 87.5
		while currad > 0 do
			if a > 0 then
				circletexture:diffuse(65/255, 124/255, 91/255, 1)
				gridtexture:diffuse(31/255, 187/255, 119/255, 0.3)
				gridtexture:rotationz(55)
				
			else
				circletexture:diffuse(31/255, 187/255, 119/255, 1)
				gridtexture:diffuse(65/255, 124/255, 91/255, 0.3)
				gridtexture:rotationz(10)
			end
			circle:xywh(sw/2,sh/2,currad*2*64/100,currad*2*64/100)
			circle:Draw()
			circletexture:Draw()
			gridtexture:Draw()
			clearbuffer:Draw()
			a = a * -1
			--print(currad)
			currad = currad - raddiff
		end
	end)
end}

func{0, function()
	
	--slumpage setup (none of this matters on the non-slump bc cover will never fade in)
	
	flashlight:hidden(0)
	flashlight:zwrite(1)
	flashlight:xywh(sw/2, sh/2, 2*sw/3, 2*sw/3)
	flashlight:blend('noeffect')
	
	cover:hidden(0)
	cover:diffuse(0.1,0.1,0.1,0.0)
	cover:xywh(sw/2, sh/2, sw*2, sw*2)
	cover:ztest(1)
	cover:ztestmode('writeonpass')
	
	flashlightframe:SetDrawFunction(function()
		for i=0,circleCount do
			flashlight:xywh(sw/2 + math.cos((flashRot/(math.pi*200)) + i * 2 * math.pi / circleCount)*flashDist, sh/2 + math.sin((flashRot/(math.pi*200)) + i * 2 * math.pi / circleCount)*flashDist, flashSize, flashSize)
			flashlight:Draw()
		end
		cover:Draw()
	end)
end}

for loop=0,1 do
	local pol = 1
	if loop == 1 then
		pol = -1
	end
	for i=0+96*loop,16+96*loop,16 do
		ease{i+0, 1, bounce, 100, 'tipsy', 150, 'drunk'}
		add{i+0, 1, bounce, 100, 'modtimeroffset'}
		add{i+1, 1, bounce, 100, 'modtimeroffset'}
		ease{i+1, 1, bounce, -100, 'tipsy', -150, 'drunk'}
		ease{i+2, 0.5, outBack, 100, 'invert', 20, 'drunk', 30, 'tipsy'}
		ease{i+2.5, 0.5, outBack, 0, 'invert', 100, 'flip', -20, 'drunk', -30, 'tipsy'}
		add{i+3, 1, outCubic, pol*180, 'rotz', 20, 'drunk', 30, 'tipsy'}

		ease{i+4, 1, bounce, 100, 'tipsy', 150, 'drunk'}
		ease{i+5, 1, bounce, -100, 'tipsy', -150, 'drunk'}
		ease{i+6, 0.5, outBack, -100, 'invert', 20, 'drunk', 30, 'tipsy'}
		ease{i+6.5, 0.5, outBack, 0, 'invert', 0, 'flip', -20, 'drunk', -30, 'tipsy'}
		add{i+7, 1, outCubic, pol*180, 'rotz', 20, 'drunk', 30, 'tipsy'}
	end

	ease{8+96*loop, 2, bounce, 50, 'tipsy', 100, 'drunk'}
	ease{10+96*loop, 2, bounce, -50, 'tipsy', -100, 'drunk'}
	ease{9+96*loop, 2, inOutSine, 150, 'mini', 100, 'blur'}
	ease{12+96*loop, 1, outSine, 0, 'blur'}
	ease{12+96*loop, 3, outElastic, 0, 'mini'}
	ease{12+96*loop, 1, outCubic, 100, 'tipsy', -100, 'drunk'}
	add{12+96*loop, 2, outCubic, 500, 'modtimeroffset'}
	ease{13+96*loop, 3, outCubic, 0, 'tipsy', 0, 'drunk'}
	add{12+96*loop, 4, outCubic, 360*pol, 'roty'}
	set{23.5+96*loop, 0, 'beat'}

	set{24+96*loop, 500, 'y', 0, 'rotz', -150*pol, 'x', 0, 'drunk', 0, 'tipsy', plr={2}}
	set{24+96*loop, 0, 'rotz', plr={1}}
	ease{24+96*loop, 1.5, outCubic, 0, 'y', 10, 'rotz', -50*pol, 'x', plr={2}}
	ease{24+96*loop, 1.5, inCubic, 500, 'y', 50*pol, 'x', 350, 'drunk', 100, 'tipsy', plr={1}}
	
	set{25.5+96*loop, 100, 'reverse', -500, 'y', 0, 'rotz', 150*pol, 'x', 0, 'drunk', 0, 'tipsy', plr={1}}
	ease{25.5+96*loop, 2, outCubic, 0, 'y', 20, 'rotz', 50*pol, 'x', plr={1}}
	ease{25.5+96*loop, 2, inCubic, 500, 'y', 40, 'rotz', -50*pol, 'x', 350, 'drunk', 100, 'tipsy', plr={2}}
	
	set{27.5+96*loop, 100, 'reverse', -500, 'y', 0, 'rotz', -50*pol, 'x', 0, 'drunk', 0, 'tipsy', plr={2}}
	ease{27.5+96*loop, 2, outCubic, 0, 'y', -10, 'rotz', -150*pol, 'x', plr={2}}
	ease{27.5+96*loop, 2, inCubic, -500, 'y', -40, 'rotz', 50*pol, 'x', 350, 'drunk', 100, 'tipsy', plr={1}}
	
	set{29.5+96*loop, 0, 'reverse', 500, 'y', 0, 'rotz', 50*pol, 'x', 0, 'drunk', 0, 'tipsy', plr={1}}
	ease{29.5+96*loop, 2, outCubic, 0, 'y', 0, 'rotz', 0, 'x', plr={1}}
	ease{29.5+96*loop, 2, inCubic, -600, 'y', 50, 'x', 40*pol, 'rotz', 350, 'drunk', 100, 'tipsy', plr={2}}

	set{31.5+96*loop, 0, 'rotz', 0, 'drunk', 0, 'tipsy', plr={2}}

	ease{31+96*loop, 1, inBack, 200, 'mini', plr={1,2,3,4}}

	set{32+96*loop, 0, 'totalRadius', 50, 'reverse', 50, 'flip', 102, 'splinextype', 102, 'splineytype', 100, 'stealthpastreceptors', 100, 'spiralholds', 60, 'tiny', -100, 'arrowpathdrawdistanceback', 0, 'x', 0, 'y', 0, 'rotz', 200, 'grain', plr={1,2,3,4}}
	set{32+96*loop, -1, 'dir', -50, 'spin', plr={3,4}}
	set{32+96*loop, 1, 'dir', 0, 'spin', plr={1,2}}
	set{32+96*loop, 100, 'halgun', plr={1,2,3,4}} --:gun:
	
	
	
	func_ease{31+96*loop, 1, inBack, 1, function(a)
		PC[1]:zoom(1-a)
		PJ[1]:zoom(1-a)
		PC[2]:zoom(1-a)
		PJ[2]:zoom(1-a)
	end}
	
	func{32+96*loop, function()
		for pn=1,4 do
			PP[pn][1]:hidden(0)
		end
	end}
	func_ease{32+96*loop, 4, outCubic, 1, function(a)
		PC[1]:x(sw/2-30*a)
		PC[1]:y(sh/2-10*a)
		PC[1]:zoom(0.4*a)
		
		PJ[1]:x(sw/2-30*a)
		PJ[1]:y(sh/2-10*a)
		PJ[1]:zoom(0.4*a)
		
		PC[2]:x(sw/2+30*a)
		PC[2]:y(sh/2+20*a)
		PC[2]:zoom(0.4*a)
		
		PJ[2]:x(sw/2+30*a)
		PJ[2]:y(sh/2+20*a)
		PJ[2]:zoom(0.4*a)
	end}

	for b=32+9,32+61,2 do
		add{b+96*loop, 1, outCubic, 50 * pol, 'totalRadius',plr={1,2,3,4}}
	end

	set{32+96*loop, 100, 'cmod', 200, 'mini', 0, 'bggap', plr={1,2,3,4}}
	ease{32+96*loop, 4, outCubic, 100, 'bggap', 100, 'mini', plr={1,2,3,4}}
	ease{38+96*loop, 2, outSine, 150, 'cmod', 100, 'minestealth', plr={1,2,3,4}}
	add{38+96*loop, 2, bounce, -10, 'spin', plr={1,2}}
	add{40+96*loop, 56, linear, 20*55, 'spin', plr={1,2}}
	add{38+96*loop, 2, bounce, 10, 'spin', plr={3,4}}
	add{40+96*loop, 56, linear, -20*55, 'spin', plr={3,4}}
	
	if slumpo then
		func_ease{36+96*loop, 4, outCubic, 1, function(a)
			cover:diffuse(0.08,0.1,0.08,a)
		end}
		set{32+96*loop, 4 - loop, 'circlecount', 0, 'flashdist', 200, 'flashsize'}
		ease{38+96*loop, 4, outCubic, 200, 'flashdist', 250 + 50*loop, 'flashsize'}
		ease{38+96*loop, 2, bounce, -10*pol, 'flashrot'}
		ease{40+96*loop, 56, bounce, 40*55, 'flashrot'}
		
		ease{42+96*loop, 2, inOutCubic, 170, 'flashdist', -60+250 + 50*loop, 'flashsize'}
		ease{47+96*loop, 2, inOutCubic, 190, 'flashdist', -20+250 + 50*loop, 'flashsize'}
		ease{55+96*loop, 2, inOutCubic, 220, 'flashdist', 40+250 + 50*loop, 'flashsize'}
		ease{58+96*loop, 2, inOutCubic, 170, 'flashdist', -60+250 + 50*loop, 'flashsize'}
		ease{63+96*loop, 2, inOutCubic, 200, 'flashdist', 0+250 + 50*loop, 'flashsize'}
		ease{71+96*loop, 2, inOutCubic, 235, 'flashdist', 70+250 + 50*loop, 'flashsize'}
		ease{74+96*loop, 2, inOutCubic, 180, 'flashdist', -40+250 + 50*loop, 'flashsize'}
		ease{79+96*loop, 2, inOutCubic, 200, 'flashdist', 0+250 + 50*loop, 'flashsize'}
		ease{87+96*loop, 2, inOutCubic, 235, 'flashdist', 70+250 + 50*loop, 'flashsize'}
		ease{90+96*loop, 2, inOutCubic, 180, 'flashdist', -40+250 + 50*loop, 'flashsize'}
	end
	-- the zoom

	ease{38+96*loop, 4, inOutCubic, 200, 'bggap', 0, 'mini', plr={1,2,3,4}}
	ease{42+96*loop, 2, inOutCubic, 140, 'bggap', 60, 'mini', plr={1,2,3,4}}
	ease{47+96*loop, 2, inOutCubic, 180, 'bggap', 20, 'mini', plr={1,2,3,4}}
	ease{55+96*loop, 2, inOutCubic, 240, 'bggap', -40, 'mini', plr={1,2,3,4}}
	ease{58+96*loop, 2, inOutCubic, 140, 'bggap', 60, 'mini', plr={1,2,3,4}}
	ease{63+96*loop, 2, inOutCubic, 200, 'bggap', 0, 'mini', plr={1,2,3,4}}
	ease{71+96*loop, 2, inOutCubic, 270, 'bggap', -70, 'mini', plr={1,2,3,4}}
	ease{74+96*loop, 2, inOutCubic, 160, 'bggap', 40, 'mini', plr={1,2,3,4}}
	ease{79+96*loop, 2, inOutCubic, 200, 'bggap', 0, 'mini', plr={1,2,3,4}}
	ease{87+96*loop, 2, inOutCubic, 270, 'bggap', -70, 'mini', plr={1,2,3,4}}
	ease{90+96*loop, 2, inOutCubic, 160, 'bggap', 40, 'mini', plr={1,2,3,4}}
	--ease{95, 2, inOutCubic, 200, 'bggap', 0, 'mini', plr={1,2,3,4}}	
end

ease{94, 2, inCubic, -1200, 'mini', 150, 'tiny', plr={3,4}}
ease{94, 1, inCubic, -800, 'mini', 100, 'tiny', plr={1,2}}
set{95, -42069, 'totalRadius', 200, 'mini', 0, 'tiny', 0, 'reverse', 0, 'flip', plr={1,2}}
set{95, 100, 'splinexreset', 100, 'splineyreset', 100, 'splinestealthreset', 100, 'splinesizereset'}
for i=0,3 do
	set{95, 0, 'arrowpath'..i}
end
ease{95, 1, outCubic, 0, 'mini', 200, 'cmod', 2100, 'bggap', plr={1,2}}
ease{95, 2, outCubic, 0, 'flashdist'}
func{96, function()
	for pn=3,4 do
		PP[pn][1]:hidden(1)
	end
end}
set{96, 0,  'minestealth', plr={1,2,3,4}}

func_ease{95, 2, outCubic, 1, function(a)
	PC[1]:x(sw/2-30-130*a)
	PC[1]:y(sh/2-10+10*a)
	PC[1]:zoom(0.4+0.6*a)
	
	PJ[1]:x(sw/2-30-130*a)
	PJ[1]:y(sh/2-10+10*a)
	PJ[1]:zoom(0.4+0.6*a)
	
	PC[2]:x(sw/2+30+130*a)
	PC[2]:y(sh/2+20-20*a)
	PC[2]:zoom(0.4+0.6*a)
	
	PJ[2]:x(sw/2+30+130*a)
	PJ[2]:y(sh/2+20-20*a)
	PJ[2]:zoom(0.4+0.6*a)
end}
if slumpo then
	func_ease{95, 2, outCubic, 1, function(a)
		cover:diffuse(0.08,0.1,0.08,1-a)
	end}
end
set{95.5, 100, 'beat'}

func{96+30, function()
	bgcircleframe:SetDrawFunction(function()
		-- invert bg texture for these few beats so that the transition is less jarring
		circletexture:diffuse(65/255, 124/255, 91/255, 1)
		gridtexture:diffuse(31/255, 187/255, 119/255, 0.3)
		gridtexture:rotationz(55)
		circle:xywh(sw/2,sh/2,sw*2,sw*2)
		circle:Draw()
		circletexture:Draw()
		gridtexture:Draw()
		clearbuffer:Draw()
		
		-- concentric circles
		local raddiff = bggap
		local scale = raddiff/200
		local currad = (modulo(scale*totrad + 150, raddiff) + 20*raddiff)
		local a = -1
		
		if modulo((scale*totrad+150) / raddiff, 2) >= 1 then
			a = 1
		end
		local idkvariablenames = 200-bggap
		currad = currad - (25 + idkvariablenames*0.625) -- center playfields in color gaps (idk why these numbers work)
		--0 mini/200 bggap - 25
		--50 mini/150 bggap - 56.25
		--100 mini/100 bggap - 87.5
		while currad > 0 do
			if a > 0 then
				circletexture:diffuse(65/255, 124/255, 91/255, 1)
				gridtexture:diffuse(31/255, 187/255, 119/255, 0.3)
				gridtexture:rotationz(55)
				
			else
				circletexture:diffuse(31/255, 187/255, 119/255, 1)
				gridtexture:diffuse(65/255, 124/255, 91/255, 0.3)
				gridtexture:rotationz(10)
			end
			circle:xywh(sw/2,sh/2,currad*2*64/100,currad*2*64/100)
			circle:Draw()
			circletexture:Draw()
			gridtexture:Draw()
			clearbuffer:Draw()
			a = a * -1
			--print(currad)
			currad = currad - raddiff
		end
	end)
end}

func{96+36, function()
	bgcircleframe:SetDrawFunction(function()
		-- invert bg texture for these few beats so that the transition is less jarring
		circletexture:diffuse(31/255, 187/255, 119/255, 1)
		gridtexture:diffuse(65/255, 124/255, 91/255, 0.3)
		gridtexture:rotationz(10)
		circle:xywh(sw/2,sh/2,sw*2,sw*2)
		circle:Draw()
		circletexture:Draw()
		gridtexture:Draw()
		clearbuffer:Draw()
		
		-- concentric circles
		local raddiff = bggap
		local scale = raddiff/200
		local currad = (modulo(scale*totrad + 150, raddiff) + 20*raddiff)
		local a = -1
		
		if modulo((scale*totrad+150) / raddiff, 2) >= 1 then
			a = 1
		end
		local idkvariablenames = 200-bggap
		currad = currad - (25 + idkvariablenames*0.625) -- center playfields in color gaps (idk why these numbers work)
		--0 mini/200 bggap - 25
		--50 mini/150 bggap - 56.25
		--100 mini/100 bggap - 87.5
		while currad > 0 do
			if a > 0 then
				circletexture:diffuse(65/255, 124/255, 91/255, 1)
				gridtexture:diffuse(31/255, 187/255, 119/255, 0.3)
				gridtexture:rotationz(55)
				
			else
				circletexture:diffuse(31/255, 187/255, 119/255, 1)
				gridtexture:diffuse(65/255, 124/255, 91/255, 0.3)
				gridtexture:rotationz(10)
			end
			circle:xywh(sw/2,sh/2,currad*2*64/100,currad*2*64/100)
			circle:Draw()
			circletexture:Draw()
			gridtexture:Draw()
			clearbuffer:Draw()
			a = a * -1
			--print(currad)
			currad = currad - raddiff
		end
	end)
end}

ease{191, 1, inCubic, 200, 'mini', 0, 'bggap', plr={1,2,3,4}}
ease{191, 1, inCubic, 0, 'flashdist', 500, 'flashsize'}